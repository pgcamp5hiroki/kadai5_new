public class New1 {
    public static void main(String[] args) {
        String[] qn;
        qn = new String[6];
        qn[0] = "今の気分の料理は何ですか？";
        qn[1] = "好きなスポーツは何ですか？";
        qn[2] = "好きな異性のタイプは何ですか？";
        qn[3] = "好きな髪形は何ですか？";
        qn[4] = "欲しいものは何ですか？";
        qn[5] = "世界の半分をくれてやろうか？";

        String[] as;
        as = new String[6];
        as[0] = "1: インド料理 2: イタリアン 3: フレンチ 4: 和食 ";
        as[1] = "1: 相撲 2: サッカー 3: 野球 4: 卓球 5: 終了";
        as[2] = "1: 世話焼き幼馴染系 2: クールな優等生系 3: 明るいドジっ子系 4: のんびり不思議系";
        as[3] = "1: 髪の毛はいらない・・・ 2: ベリーショート 3: ショート 4: ロング ";
        as[4] = "1: 家電製品 2: 彼氏or彼 3: 目の前を覆いつくす札束 4: 永遠の命 ";
        as[5] = "1: Yes 2: No 3: それはドラk・・・・ ";


        System.out.println(qn[0]);
        System.out.println(as[0]);
        java.util.Scanner sa = new java.util.Scanner(System.in);
        int a = sa.nextInt();
        if (a <= 4) {
            System.out.println("次の問題へ");
        } else if (a == 5) {
            System.out.println("終了");

        }else {
            System.out.println("1～4の番号を入力して下さい。");
        }


        System.out.println(qn[1]);
        System.out.println(as[1]);
        java.util.Scanner sb = new java.util.Scanner(System.in);
        int b = sb.nextInt();
        if (b <= 4) {
            System.out.println("次の問題へ");
        } else {
            System.out.println("1～4の番号を入力して下さい。");
        }

        System.out.println(qn[2]);
        System.out.println(as[2]);
        java.util.Scanner sc = new java.util.Scanner(System.in);
        int c = sc.nextInt();
        if (c <= 4) {
            System.out.println("次の問題へ");
        } else {
            System.out.println("1～4の番号を入力して下さい。");
        }

        System.out.println(qn[3]);
        System.out.println(as[3]);
        java.util.Scanner sd = new java.util.Scanner(System.in);
        int d = sd.nextInt();
        if (d <= 4) {
            System.out.println("次の問題へ");
        } else {
            System.out.println("1～4の番号を入力して下さい。");
        }

        System.out.println(qn[4]);
        System.out.println(as[4]);
        java.util.Scanner se = new java.util.Scanner(System.in);
        int e = sc.nextInt();
        if (a + b + c + d + e < 15) {
            System.out.println("相性は普通です");
        } else {
            System.out.println("1～4の番号を入力して下さい。");


        }
        if (a + b + c + d + e >= 15) {
            System.out.println(qn[5]);
            System.out.println(as[5]);
            java.util.Scanner sf = new java.util.Scanner(System.in);
            int f = sf.nextInt();
            if (f == 3) {
                System.out.println("相性は最高です");
            } else if (f == 2) {
                System.out.println("相性は最悪です");
            } else if (f == 1) {
                System.out.println("GAME OVER");
            } else {
                System.out.println("1～4の番号を入力して下さい。");


            }
        }
    }}



